import {Injectable} from '@angular/core';

@Injectable()
export class SearchFilter
{
	type: String="rent";
}