export class SearchFilter
{
	type: String="rent";
	searchValue: String;
}