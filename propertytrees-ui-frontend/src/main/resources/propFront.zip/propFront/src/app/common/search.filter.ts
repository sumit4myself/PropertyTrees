export class SearchFilter
{
	type: String="rent";
}