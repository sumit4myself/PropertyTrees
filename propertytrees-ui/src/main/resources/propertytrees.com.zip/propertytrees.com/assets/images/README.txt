demo/ - contains the demo images only!
You can remove it on production!

You can also use any image you want from demo/ folder.